 .Sol file Watershed HRU:168 Subbasin:5 HRU:5 Luse:AGRR Soil: COLTON Slope: 2-7 2/21/2019 12:00:00 AM ArcSWAT 2012.10_3.19
 Soil Name: COLTON
 Soil Hydrologic Group: C
 Maximum rooting depth(mm) : 1828.80
 Porosity fraction from which anions are excluded: 0.500
 Crack volume potential of soil: 0.500
 Texture 1                : Moraine
 Depth                [mm]:      203.20      228.60
 Bulk Density Moist [g/cc]:        1.25        1.30
 Ave. AW Incl. Rock Frag  :        0.15        0.15
 Ksat. (est.)      [mm/hr]:       80.00     1200.00
 Organic Carbon [weight %]:        2.33        0.38
 Clay           [weight %]:       10.00       10.00
 Silt           [weight %]:       30.00       30.00
 Sand           [weight %]:       60.00       60.00
 Rock Fragments   [vol. %]:       40.00       40.00
 Soil Albedo (Moist)      :        0.13        0.13
 Erosion K                :        0.18        0.24
 Salinity (EC, Form 5)    :        1.00        0.00
 Soil pH                  :        7.00        0.00
 Soil CACO3               :        5.00        0.00
                              
