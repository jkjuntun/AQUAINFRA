 .Sol file Watershed HRU:9 Subbasin:1 HRU:9 Luse:HAY Soil: CARLISLE Slope: 2-7 2/21/2019 12:00:00 AM ArcSWAT 2012.10_3.19
 Soil Name: CARLISLE
 Soil Hydrologic Group: A
 Maximum rooting depth(mm) :  600.00
 Porosity fraction from which anions are excluded: 0.110
 Crack volume potential of soil: 0.500
 Texture 1                : Peat
 Depth                [mm]:      300.00     1700.00
 Bulk Density Moist [g/cc]:        1.10        1.48
 Ave. AW Incl. Rock Frag  :        0.35        0.35
 Ksat. (est.)      [mm/hr]:       17.00     1000.00
 Organic Carbon [weight %]:        9.88        9.99
 Clay           [weight %]:        5.00       80.00
 Silt           [weight %]:       15.00       15.00
 Sand           [weight %]:       80.00        5.00
 Rock Fragments   [vol. %]:        0.00        1.00
 Soil Albedo (Moist)      :        0.10        0.17
 Erosion K                :        0.24        0.15
 Salinity (EC, Form 5)    :        0.10        0.10
 Soil pH                  :        6.00        6.00
 Soil CACO3               :        5.00        5.00
                              
