 .Sol file Watershed HRU:399 Subbasin:11 HRU:17 Luse:WATR Soil: WATER Slope: 0-2 2/21/2019 12:00:00 AM ArcSWAT 2012.10_3.19
 Soil Name: WATER
 Soil Hydrologic Group: D
 Maximum rooting depth(mm) :   25.40
 Porosity fraction from which anions are excluded: 0.500
 Crack volume potential of soil: 0.500
 Texture 1                :  
 Depth                [mm]:       25.40
 Bulk Density Moist [g/cc]:        1.72
 Ave. AW Incl. Rock Frag  :        0.00
 Ksat. (est.)      [mm/hr]:      260.00
 Organic Carbon [weight %]:        0.00
 Clay           [weight %]:        0.00
 Silt           [weight %]:        0.00
 Sand           [weight %]:        0.00
 Rock Fragments   [vol. %]:        0.00
 Soil Albedo (Moist)      :        0.23
 Erosion K                :        0.01
 Salinity (EC, Form 5)    :        0.00
 Soil pH                  :        0.00
 Soil CACO3               :        0.00
                              
