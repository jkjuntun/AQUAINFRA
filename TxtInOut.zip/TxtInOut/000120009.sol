 .Sol file Watershed HRU:408 Subbasin:12 HRU:9 Luse:FRST Soil: COVINGTON Slope: 7-9999 2/21/2019 12:00:00 AM ArcSWAT 2012.10_3.19
 Soil Name: COVINGTON
 Soil Hydrologic Group: D
 Maximum rooting depth(mm) :  750.00
 Porosity fraction from which anions are excluded: 0.500
 Crack volume potential of soil: 0.300
 Texture 1                : Clay
 Depth                [mm]:      190.00      750.00     1651.00
 Bulk Density Moist [g/cc]:        2.00        1.90        1.35
 Ave. AW Incl. Rock Frag  :        0.21        0.21        0.13
 Ksat. (est.)      [mm/hr]:        1.20        0.60        0.12
 Organic Carbon [weight %]:        5.81        1.94        0.65
 Clay           [weight %]:       47.00       75.00       75.00
 Silt           [weight %]:       37.00       17.58       17.58
 Sand           [weight %]:       16.00        7.42        7.42
 Rock Fragments   [vol. %]:        1.29        1.29        1.29
 Soil Albedo (Moist)      :        0.01        0.01        0.07
 Erosion K                :        0.30        0.30        0.50
 Salinity (EC, Form 5)    :        1.00        1.00        1.00
 Soil pH                  :        7.00        7.00        7.00
 Soil CACO3               :        5.00        5.00        5.00
                              
