 .Sol file Watershed HRU:328 Subbasin:9 HRU:34 Luse:URBN Soil: ROCK OUTCROP Slope: 7-9999 2/21/2019 12:00:00 AM ArcSWAT 2012.10_3.19
 Soil Name: ROCK OUTCROP
 Soil Hydrologic Group: D
 Maximum rooting depth(mm) :  600.00
 Porosity fraction from which anions are excluded: 0.500
 Crack volume potential of soil: 0.500
 Texture 1                : Rock
 Depth                [mm]:      100.00      600.00     1300.00
 Bulk Density Moist [g/cc]:        1.10        1.60        2.20
 Ave. AW Incl. Rock Frag  :        0.15        0.15        0.04
 Ksat. (est.)      [mm/hr]:      500.00     1050.00        1.00
 Organic Carbon [weight %]:        3.00        0.90        0.05
 Clay           [weight %]:       10.00        2.50       33.00
 Silt           [weight %]:       45.00       52.50       33.00
 Sand           [weight %]:       45.00       45.00       34.00
 Rock Fragments   [vol. %]:       30.00       40.00      100.00
 Soil Albedo (Moist)      :        0.13        0.13        0.00
 Erosion K                :        0.24        0.15        0.00
 Salinity (EC, Form 5)    :        0.10        0.10        0.10
 Soil pH                  :        7.00        7.00        7.00
 Soil CACO3               :        5.00        5.00        5.00
                              
