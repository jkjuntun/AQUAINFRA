 .Sol file Watershed HRU:145 Subbasin:4 HRU:42 Luse:UIDU Soil: LIMERICK Slope: 7-9999 2/21/2019 12:00:00 AM ArcSWAT 2012.10_3.19
 Soil Name: LIMERICK
 Soil Hydrologic Group: A
 Maximum rooting depth(mm) :  600.00
 Porosity fraction from which anions are excluded: 0.700
 Crack volume potential of soil: 0.500
 Texture 1                : Coarse
 Depth                [mm]:       50.00     1950.00
 Bulk Density Moist [g/cc]:        1.30        1.60
 Ave. AW Incl. Rock Frag  :        0.04        0.04
 Ksat. (est.)      [mm/hr]:     1050.00     1500.00
 Organic Carbon [weight %]:        2.03        0.29
 Clay           [weight %]:        2.50        2.50
 Silt           [weight %]:       15.00        7.50
 Sand           [weight %]:       82.50       90.00
 Rock Fragments   [vol. %]:       30.00       30.00
 Soil Albedo (Moist)      :        0.13        0.13
 Erosion K                :        0.18        0.15
 Salinity (EC, Form 5)    :        1.00        1.00
 Soil pH                  :        7.00        7.00
 Soil CACO3               :        5.00        5.00
                              
